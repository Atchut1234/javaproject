package com.ecommerce.digicart.controller;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.digicart.model.User;
import com.ecommerce.digicart.service.UserService;
import com.ecommerce.digicart.utils.Payment;
import com.ecommerce.digicart.utils.Response;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;

@RestController
public class UserController {
	@Autowired
	private UserService userService;
	
	@RequestMapping("/healthCheck")
	public String healthCheck() {
		System.out.println("-------in healthcheck------");
		return "app is running successfully";
	}
	
	@PostMapping("/register")
	public ResponseEntity<Object> register(@RequestBody User user) {
		System.out.println("---register-----");
		System.out.println(user.getEmail());
		boolean result = userService.register(user);
		Response response = null;
		if(result == true) {
			response = new Response();
			response.setMessage("registration successfull");
			response.setOperationStatus("success");
			return new ResponseEntity<Object>(response, HttpStatus.OK);
			
		}
		else {
			response = new Response();
			response.setMessage("registration failure");
			response.setOperationStatus("failure");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}
			
	}
	
	@PostMapping("/login")
	public ResponseEntity<Object> login(@RequestBody User user) {
		boolean result = userService.login(user);
		Response response = null;
		if(result == true) {
			response = new Response();
			response.setMessage("login successfull");
			response.setOperationStatus("success");
			return new ResponseEntity<Object>(response, HttpStatus.OK);
			
		}
		else {
			response = new Response();
			response.setMessage("login failure");
			response.setOperationStatus("failure");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}
	}
	
	@PostMapping("/createOrder")
	public ResponseEntity<Object> createOrder(@RequestBody Payment payment) throws RazorpayException{
		RazorpayClient client = new RazorpayClient("rzp_test_gEE3zikkBR7gtR","kuzjLCBr3Mv9pciLHkNLUrvR");
		
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("amount",payment.getAmount());
		jsonObject.put("currency",payment.getCurrency());
		
		Order order = client.orders.create(jsonObject);
		Response response = new Response();
		response.setMessage(order.get("id"));
		response.setOperationStatus("created");
		return new ResponseEntity<Object> (response,HttpStatus.CREATED);
		
		
		
		
	}

}

//rzp_test_5YIFFJFbWhVu3h id
//rzp_test_5YIFFJFbWhVu3h  value
