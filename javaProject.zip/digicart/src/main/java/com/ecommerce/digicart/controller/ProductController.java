package com.ecommerce.digicart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.digicart.model.Product;
import com.ecommerce.digicart.service.ProductService;
import com.ecommerce.digicart.utils.Response;
@RequestMapping("/product")
@RestController
public class ProductController {
	
	@Autowired
	private ProductService productService;
	
	@GetMapping("/add")
	public ResponseEntity<Object> add(@RequestBody Product product){
		System.out.println("product desc" + product.getDescription());
		
		boolean result = productService.add(product);
		
		if(result = true) {
			Response response = new Response();
			response.setMessage("product added successfully");
			response.setOperationStatus("success");
			return new ResponseEntity<Object>(response,HttpStatus.CREATED);
		}
		else {
			Response response = new Response();
			response.setMessage("product adding failed");
			response.setOperationStatus("failure");
			return new ResponseEntity<Object>(response,HttpStatus.BAD_REQUEST);
		}
		
	}
	
	@DeleteMapping("/delete")
	public ResponseEntity<Object> delete(@RequestBody Product product){
		System.out.println("inside controller");
		boolean result = productService.delete(product);
		
		if(result = true) {
			Response response = new Response();
			response.setMessage("product delete successfully");
			response.setOperationStatus("scccess");
			return new ResponseEntity<Object>(response,HttpStatus.CREATED);
		}
		else {
			Response response = new Response();
			response.setMessage("product delete failed");
			response.setOperationStatus("failure");
			return new ResponseEntity<Object>(response,HttpStatus.BAD_REQUEST);
		}
		
	}
	
	@GetMapping("/list")
	public ResponseEntity<Object> list(){
		System.out.println("inside controller");
		List<Product> products= productService.list();
		return new ResponseEntity<Object>(products,HttpStatus.OK);
	
	}
	
	@PutMapping("/update")
	public ResponseEntity<Object> update(@RequestBody Product product){
		System.out.println("inside controller");
		boolean result = productService.update(product);
		
		if(result = true) {
			Response response = new Response();
			response.setMessage("product updated successfully");
			response.setOperationStatus("scccess");
			return new ResponseEntity<Object>(response,HttpStatus.CREATED);
		}
		else {
			Response response = new Response();
			response.setMessage("product updation failed");
			response.setOperationStatus("failure");
			return new ResponseEntity<Object>(response,HttpStatus.BAD_REQUEST);
		}
		
		
	}
}

//  rzp_test_5YIFFJFbWhVu3h id
//  rzp_test_5YIFFJFbWhVu3h  value
