package com.ecommerce.digicart.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ecommerce.digicart.model.Product;
@Repository
public class ProductDAOimpl implements ProductDAO {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public boolean add(Product product) {
		boolean result = false;
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		int i = (int) session.save(product);
		transaction.commit();
		if(i != 0) {
			return true;
		}
		return result;
	}

	@Override
	public List<Product> list() {
		Session session = sessionFactory.openSession();
		List<Product> list = session.createQuery("from Product").list();
		return list;
	}

	@Override
	public boolean update(Product product) {
		boolean result = false;
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		int i =  (int) session.save(product);
		transaction.commit();
		if(i != 0) {
			return true;
		}
		return result;
		
	}

	@Override
	public boolean delete(Product product) {
		System.out.println("inside DAO");
		boolean result = false;
		Session session = sessionFactory.openSession();
		
		Transaction transaction = session.beginTransaction();
		try {
			Product pro = (Product) session.merge(product);
			session.remove(pro);
			transaction.commit();
			result = true;
		}
		catch(Exception e) {
			System.out.println(e);
			result = false;
		}
		session.delete(product);
		return result;
	}

}
