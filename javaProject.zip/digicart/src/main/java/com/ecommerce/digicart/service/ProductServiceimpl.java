package com.ecommerce.digicart.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.digicart.dao.ProductDAO;
import com.ecommerce.digicart.model.Product;

@Service
public class ProductServiceimpl implements ProductService {
	
	@Autowired
	private ProductDAO productDAO;

	@Override
	public boolean add(Product product) {
		return productDAO.add(product);
		
	}

	@Override
	public List<Product> list() {
		return productDAO.list();
		
	}

	@Override
	public boolean update(Product product) {
		return productDAO.update(product);
	}

	@Override
	public boolean delete(Product product) {
		System.out.println("inside service");
		return productDAO.delete(product);
		
	}
	
	

}
