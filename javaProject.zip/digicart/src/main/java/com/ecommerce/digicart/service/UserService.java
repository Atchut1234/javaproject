package com.ecommerce.digicart.service;

import com.ecommerce.digicart.model.User;

public interface UserService {
	
	public boolean register(User user); 
	public boolean login(User user);

}
