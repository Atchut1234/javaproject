package com.ecommerce.digicart.dao;

import com.ecommerce.digicart.model.User;

public interface UserDAO {
	
	public boolean register(User user); 
	public boolean login(User user);
		
	

}
